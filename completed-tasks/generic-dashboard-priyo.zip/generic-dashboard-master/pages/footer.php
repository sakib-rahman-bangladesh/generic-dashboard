
            <footer class="footer ">
                <div class="container-fluid">
                    <nav class="pull-left">
                        <ul>
                            <li>
                                <a href="http://dma-bd.com">
                                    DMA-BD
                                </a>
                            </li>
                            <li>
                                <a href="http://dma-bd.com/about-me">
                                    About Us
                                </a>
                            </li>
                            <li>
                                <a href="http://dma-bd.com/collaboration">
                                Collaboration
                                </a>
                            </li>
                            <li>
                                <a href="http://dma-bd.com/products">
                                    Products
                                </a>
                            </li>
                        </ul>
                    </nav>
                    <div class="copyright pull-right">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>, Developed by
                        <a href="https://www.dma-bd.com" target="_blank">Datasoft Manufacturing & Assembly Inc. Ltd.</a>
                    </div>
                </div>
            </footer>