import shutil

for i in range(50):
		shutil.copy2('C:/Users/toll/Desktop/DMA_Nuha/24th_June/basic_SendByteData_CS/v1.3_SaveDB_50clients/Clients_50/client.py', 'C:/Users/toll/Desktop/DMA_Nuha/24th_June/basic_SendByteData_CS/v1.3_SaveDB_50clients/Clients_50/client{}.py'.format(i))
	