for py_file in $(find $v1.2_50Clients -client *.py)
do
    python $py_file
done
