import shutil

for i in range(50):
    shutil.copy2('C:/Users/toll/Desktop/DMA_Nuha/21th_June/ClientServer_UsingThreadPool_OK/v1.2_50Clients/client.py', 'C:/Users/toll/Desktop/DMA_Nuha/21th_June/ClientServer_UsingThreadPool_OK/v1.2_50Clients/client{}.py'.format(i))
